<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: 'Nunito', sans-serif;
            background-color: #ECECEC;
        }
    </style>
</head>
<body>

<a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a><br><br>
    <form enctype="multipart/form-data" action="<?php echo e(url('cangeUser')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label form="nombre">Nom:</label> 
        <input name="nom" type="text" value="<?php echo e($nom); ?>">
        <br><br>
        <label form="email">Email:</label> 
        <input name="email" type="text" value="<?php echo e($email); ?>">
        <br><br>
        <label form="cognom">Cognoms:</label> 
        <input name="cognom" type="text" value="<?php echo e(Auth::user()->cognoms); ?>">
        <br><br>
        <label form="nombre">Contrasenya:</label> 
        <input name="password" type="password">
        <br><br>
        <label form="nombre">Repetir Contrasenya:</label> 
        <input name="password_confirmation" type="password">
        <br><br>

        <input type="submit" value="ENVIAR">
    </form>
    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <?php if($correcte==1): ?>
        <p>S'ha canviat les dades correctament</p>
    <?php endif; ?>


    <br><br><br><form enctype="multipart/form-data" action="<?php echo e(url('cangeImgUser')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label form="imatge">Imatge perfil:</label> 
        <input type="file" name="image">
        <br><br>

        <input type="submit" value="ENVIAR">
    </form>
</body>
</html><?php /**PATH /var/www/html/dflores/M07/UF2/dflores_prova_uf2_uf3/resources/views/edicio.blade.php ENDPATH**/ ?>