<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /var/www/html/dflores/M07/UF2/dflores_prova_uf2_uf3/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>